import { NextResponse } from "next/server";
import { env } from "cloudflare:workers";
export async function POST(request: Request) {
  let input: Record<string, unknown>;
  try { input = await request.json(); } catch { return NextResponse.json({error:"Invalid request"},{status:400}); }
  const name = typeof input.name === "string" ? input.name.trim() : "";
  const attendance = input.attendance;
  const guests = attendance === "decline" ? 0 : Number(input.guests ?? 1);
  const message = typeof input.message === "string" ? input.message.trim() : "";
  if (!name || name.length > 100 || (attendance !== "accept" && attendance !== "decline") || !Number.isInteger(guests) || guests < 0 || guests > 4 || message.length > 500) return NextResponse.json({error:"Invalid response"},{status:400});
  try {
    await env.DB.prepare("INSERT INTO rsvps (name, attendance, guests, message, created_at) VALUES (?, ?, ?, ?, ?)").bind(name, attendance, guests, message, new Date().toISOString()).run();
    return NextResponse.json({ok:true});
  } catch (error) {
    console.error("RSVP save failed", error);
    return NextResponse.json({error:"Could not save response"},{status:503});
  }
}
