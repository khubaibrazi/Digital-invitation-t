"use client";
import { useEffect, useState, type FormEvent } from "react";

const date = new Date("2026-10-02T18:00:00+01:00").getTime();
export default function Home() {
  const [open, setOpen] = useState(false);
  const [left, setLeft] = useState<number | null>(null);
  const [attending, setAttending] = useState(true);
  const [status, setStatus] = useState("");
  const [busy, setBusy] = useState(false);
  useEffect(() => { const tick = () => setLeft(Math.max(0, date - Date.now())); tick(); const id = setInterval(tick, 1000); return () => clearInterval(id); }, []);
  const parts = left === null ? ["—","—","—","—"] : [Math.floor(left/86400000), Math.floor(left/3600000)%24, Math.floor(left/60000)%60, Math.floor(left/1000)%60].map(v => String(v).padStart(2,"0"));
  async function send(e: FormEvent<HTMLFormElement>) {
    e.preventDefault(); setBusy(true); setStatus("");
    const form = e.currentTarget;
    try {
      const response = await fetch("/api/rsvp", {method:"POST", headers:{"Content-Type":"application/json"}, body:JSON.stringify(Object.fromEntries(new FormData(form)))});
      if (!response.ok) throw new Error("Response save nahi hua. Dobara try karein.");
      setStatus("Thank you — your response has been received."); form.reset(); setAttending(true);
    } catch (err) { setStatus(err instanceof Error ? err.message : "Please try again."); }
    finally { setBusy(false); }
  }
  return <main>
    <div className="preview-label">TAHA ZUMAR ALI & LAIBA ASHRAF · 2 OCTOBER 2026</div>
    {!open ? <section className="opening"><div className="envelope"><div className="flap"/><div className="front"><p>You are invited</p><button className="seal" onClick={() => setOpen(true)} aria-label="Open invitation">T <small>&</small> L</button><span>Tap the seal to open</span></div></div></section> :
    <div className="reveal">
      <section className="hero"><div className="hero-copy"><div className="bismillah" lang="ar" dir="rtl">بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ</div><div className="eyebrow">WITH THE BLESSINGS OF ALLAH</div><h1>Taha Zumar Ali <em>&</em> Laiba Ashraf</h1><i className="rule"/><p>Together with their families<br/>request the honour of your presence<br/>at their Nikkah ceremony</p><div className="hero-date">02 · 10 · 2026</div><div className="eyebrow">WOKING · UNITED KINGDOM</div></div></section>
      <section className="section"><div className="eyebrow">FRIDAY, 2 OCTOBER 2026</div><h2>Save the date</h2><p>Your presence will be a blessing for us.</p><div className="countdown">{parts.map((v,i)=><div key={i}><strong>{v}</strong><span>{["Days","Hours","Minutes","Seconds"][i]}</span></div>)}</div></section>
      <section className="section celebration"><div className="eyebrow">THE CELEBRATION</div><h2>Join us</h2><div className="events">
        <article className="event"><div className="event-date">02<small>OCTOBER<br/>2026</small></div><div><h3>Nikkah</h3><p>6:00 PM</p><address>Albert House, Albert Dr,<br/>Sheerwater, Woking GU21 5JZ</address><a href="https://www.google.com/maps/search/?api=1&query=Albert+House%2C+Albert+Dr%2C+Sheerwater%2C+Woking+GU21+5JZ" target="_blank" rel="noopener noreferrer">View location ↗</a></div></article>
        <article className="event"><div className="event-date">02<small>OCTOBER<br/>2026</small></div><div><h3>Function</h3><p>7:00 PM – 11:00 PM</p><address>Church Rd, St John’s,<br/>Woking GU21 7QN</address><a href="https://www.google.com/maps/search/?api=1&query=Church+Rd%2C+St+John%27s%2C+Woking+GU21+7QN" target="_blank" rel="noopener noreferrer">View location ↗</a></div></article>
      </div></section>
      <section className="section rsvp"><div className="eyebrow">KINDLY REPLY</div><h2>RSVP</h2><p>We would love to know if you can join us.</p><form onSubmit={send}>
        <label htmlFor="guest">Your name</label><input id="guest" name="name" required maxLength={100} autoComplete="name" placeholder="Full name"/>
        <fieldset><legend>Will you attend?</legend><label className="option"><input type="radio" name="attendance" value="accept" checked={attending} onChange={()=>setAttending(true)}/> Joyfully accepts</label><label className="option"><input type="radio" name="attendance" value="decline" checked={!attending} onChange={()=>setAttending(false)}/> Regretfully declines</label></fieldset>
        {attending && <><label htmlFor="guests">Number of guests (including you)</label><select id="guests" name="guests" defaultValue="1">{[1,2,3,4].map(n=><option key={n} value={n}>{n} {n===1?"guest":"guests"}</option>)}</select></>}
        <label htmlFor="message">A note for the couple (optional)</label><textarea id="message" name="message" rows={3} maxLength={500} placeholder="Your message"/>
        <button className="submit" disabled={busy}>{busy?"Sending…":"Send response"}</button><p role="status" className="status">{status}</p>
      </form></section><footer>TAHA <span>✦</span> LAIBA <small>2 OCTOBER 2026</small></footer>
    </div>}
  </main>;
}
