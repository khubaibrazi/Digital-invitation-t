import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "Taha Zumar Ali & Laiba Ashraf | Nikkah Invitation",
  description: "Join Taha Zumar Ali and Laiba Ashraf for their Nikkah on Friday, 2 October 2026 in Woking.",
  icons: {
    icon: "/favicon.svg",
    shortcut: "/favicon.svg",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en">
      <body className="antialiased">{children}</body>
    </html>
  );
}
