# Taha & Laiba invitation source

Next.js/Vinext wedding invitation. The opening animation, countdown, event details and RSVP UI live in `app/page.tsx`; styles are in `app/globals.css`. The RSVP endpoint is `app/api/rsvp/route.ts`, backed by a Cloudflare D1 database. The migration is in `drizzle/`.

Requires Node.js 22.13+ and npm. Run `npm ci` then `npm run dev` for the UI. RSVP needs a configured Cloudflare D1 `DB` binding and the included migration; without it, submissions return an error. Replace `project_id` in `.openai/hosting.json` with your own Sites project ID if publishing through Sites.

The site uses an original floral artwork in `public/floral-frame.png`; the reference card image itself is not bundled.
